from baddeley_binary_image_metric.locmeasures2d_spatial_vx import locmeasures2d_spatial_vx
from baddeley_binary_image_metric.lib.make_spatialVx import make_spatialVx
import pyreadr


def locmeasures2d_default(grd_ob, grd_fo, thresholds, which_stats=None, k=None, alpha=None, bdconst=None, p=None):
    # ph 并没有进行计算
    if p is None:
        p = [2]
    if alpha is None:
        alpha = [0.1]
    if which_stats is None:
        which_stats = ["bdelta", "haus", "qdmapdiff", "med", "msd", "ph", "fom"]
    if grd_fo.shape != grd_ob.shape:
        raise Exception("locmeasures2d: dim of observed field (", grd_ob.shape, ") must equal dim of forecast field (",
                        grd_fo.shape, ")")
    obj = make_spatialVx(grd_ob=grd_ob, grd_fo=grd_fo, loc=None, thresholds=thresholds)
    out = locmeasures2d_spatial_vx(input_object=obj, which_stats=which_stats, k=k, alpha=alpha, bdconst=bdconst, p=p)
    return out


if __name__ == '__main__':
    geom000 = pyreadr.read_r('./data/geom000.Rdata')['geom000']
    geom001 = pyreadr.read_r('./data/geom001.Rdata')['geom001']
    look = locmeasures2d_default(geom000, geom001, [0.01, 50.01, 99.01], k=[4, 0.975], alpha=0.1)
    print("j")
