import math

from lib.kernel2dsmooth import kernel2dsmooth


def hoods2dsmooth(x, lambd, w=None, setup=False, **args):
    if math.floor(lambd) != lambd:
        print("hoods2dsmooth: attempting to give an illegal value for the neighborhood length.  Flooring lambd.")
        lambd = math.floor(lambd)

    if lambd % 2 == 0:
        print("hoods2dsmooth: attempting to give an even neighborhood length, subtracting one from it.")
        lambd = lambd - 1

    if lambd < 1:
        print("hoods2dsmooth: attempting to give an illegal value for the neighborhood length.  Setting to one, "
              "and returning x untouched.")
        lambd = 1

    if lambd == 1:
        return x
    else:
        return kernel2dsmooth(x=x, kernel_type="boxcar", n=lambd, w=w, setup=setup, **args)
