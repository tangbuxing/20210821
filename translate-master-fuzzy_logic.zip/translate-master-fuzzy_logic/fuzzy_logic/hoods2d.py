import time
import numpy as np
import pandas as pd
from fuzzy_logic.lib.datagrabber_spatialVx import datagrabber_spatialVx
from fuzzy_logic.lib.fss2dfun import fss2dfun
from fuzzy_logic.lib.fuzzyjoint2dfun import fuzzyjoint2dfun
from fuzzy_logic.lib.mincvg2dfun import mincvg2dfun
from fuzzy_logic.lib.multicon2dfun import multicon2dfun
from fuzzy_logic.lib.progmatic2dfun import pragmatic2dfun
from fuzzy_logic.lib.thresholder import thresholder
from fuzzy_logic.lib.thresholder_spatialVx import thresholder_spatialVx
from fuzzy_logic.hoods2dPrep import hoods2dPrep
from fuzzy_logic.hoods2dSetUpLists import hoods2dSetUpLists
from fuzzy_logic.hoods2dsmooth import hoods2dsmooth
import json
from fuzzy_logic.lib.make_spatialVx import make_spatialVx
import pyreadr


def hoods2d(input_object, which_methods=None, time_point=1,
            obs=0, model=0, levels=None, max_n=None, rule=">=", verbose=False):
    if which_methods is None:
        which_methods = ["mincvr", "multi_event", "fuzzy", "joint", "fss", "pragmatic"]
    smooth_fun = "hoods2dsmooth"
    smooth_params = None
    input_object['data'] = [input_object['X'], input_object['Xhat']]
    # 根据输入参数计算对应的levels, max_n
    input_object = hoods2dPrep(input_object=input_object, levels=levels,
                               max_n=max_n, smooth_fun=smooth_fun, smooth_params=smooth_params)
    if verbose:
        begin_time = time.time()
    thresholds = input_object['thresholds']
    q = thresholds[0].shape[0]
    levels = input_object['levels']
    l = len(levels)
    # 抓取数据
    dat = datagrabber_spatialVx(input_object, time_point=time_point, obs=obs, model=model)
    x = dat['X']
    outmat = np.zeros((l, q))
    pd.DataFrame(outmat, columns=json.loads(input_object["qs"]), index=levels)
    # 根据输入参数，初始化返回结果
    out = hoods2dSetUpLists(input_object=input_object, which_methods=which_methods, mat=outmat)
    sub = input_object["subset"]
    if verbose:
        print("Looping through thresholds.\n")
    for threshold in range(0, q, 1):
        if len({"mincvr", "mincvr", "multi_event", "fuzzy", "joint", "fss", "pragmatic"}.intersection(
                which_methods)) > 0:
            if verbose:
                print("\n", "Setting up binary objects for threshold ", threshold, "\n")
            # 根据thresholds, rule，替换矩阵中的元素
            dat2 = thresholder_spatialVx(input_object, func_type="binary", th=threshold, rule=rule, time_point=time_point, obs=obs,
                                         model=model)
            ix = dat2['X']
            iy = dat2['Xhat']
        if "fss" in which_methods:
            if sub is None:
                f0 = np.mean(ix)
            else:
                f0 = np.mean(ix['subset'])
            if threshold == 1:
                out["fss"]["fss_uniform"] = 0.5 + f0 / 2
                out["fss"]["fss_random"] = f0
            else:
                out["fss"]["fss_uniform"] = [out["fss"]["fss_uniform"], 0.5 + f0 / 2]
                out["fss"]["fss_random"] = [out["fss"]["fss_random"], f0]
        if verbose:
            print("Looping through levels.\n")
        for level in range(0, l, 1):
            if verbose:
                print("Neighborhood length = ", levels[level], "\n")
            # 平滑处理
            level_w = hoods2dsmooth(x, levels[level], None, True)
            if len({"mincvr", "multi_event", "fuzzy", "joint", "pragmatic", "fss"}.intersection(
                    which_methods)) > 0:
                if len({"mincvr", "multi_event", "fuzzy", "joint", "fss"}.intersection(which_methods)) > 0:
                    s_px = hoods2dsmooth(ix, levels[level], level_w)
                s_py = hoods2dsmooth(iy, levels[level], level_w)
            if len({"mincvr", "multi_event"}.intersection(which_methods)) > 0:
                s_ix = thresholder(s_px, func_type="binary", th=input_object["pe"][level])
                s_iy = thresholder(s_py, func_type="binary", th=input_object["pe"][level])
                if "mincvr" in which_methods:
                    tmp = mincvg2dfun(s_iy=s_iy, s_ix=s_ix, subset=sub)
                    out["mincvr"]["pod"][level, threshold] = tmp["pod"]
                    out["mincvr"]["far"][level, threshold] = tmp["far"]
                    out["mincvr"]["ets"][level, threshold] = tmp["ets"]

                if "multi_event" in which_methods:
                    tmp = multicon2dfun(s_iy=s_iy, ix=ix, subset=sub)
                    out["multi_event"]["pod"][level, threshold] = tmp["pod"]
                    out["multi_event"]["f"][level, threshold] = tmp["f"]
                    out["multi_event"]["hk"][level, threshold] = tmp["hk"]

            if len({"fuzzy", "joint"}.intersection(which_methods)) > 0:
                tmp = fuzzyjoint2dfun(s_py=s_py, s_px=s_px, subset=sub)
                if "fuzzy" in which_methods:
                    out["fuzzy"]["pod"][level, threshold] = tmp["fuzzy"]["pod"]
                    out["fuzzy"]["far"][level, threshold] = tmp["fuzzy"]["far"]
                    out["fuzzy"]["ets"][level, threshold] = tmp["fuzzy"]["ets"]

                if "joint" in which_methods:
                    out["joint"]["pod"][level, threshold] = tmp["joint"]["pod"]
                    out["joint"]["far"][level, threshold] = tmp["joint"]["far"]
                    out["joint"]["ets"][level, threshold] = tmp["joint"]["ets"]

            if "fss" in which_methods:
                out["fss"]["fss"][level, threshold] = fss2dfun(s_py=s_py, s_px=s_px, subset=sub)
            if "pragmatic" in which_methods:
                tmp = pragmatic2dfun(s_py=s_py, ix=ix)
                out["pragmatic"]["bs"][level, threshold] = tmp["bs"]
                out["pragmatic"]["bss"][level, threshold] = tmp["bss"]

    if verbose:
        print(time.time() - begin_time)
    out["time_point"] = time_point
    out["model_num"] = model

    return out


if __name__ == '__main__':
    geom000 = pyreadr.read_r('./data/geom000.Rdata')['geom000']
    geom001 = pyreadr.read_r('./data/geom001.Rdata')['geom001']
    ICPg240Locs = pyreadr.read_r('./data/ICPg240Locs.Rdata')['ICPg240Locs']
    hold = make_spatialVx(geom000, geom001, loc=ICPg240Locs,
                          fieldtype="Geometric Objects Pretending to be Precipitation",
                          units="mm/h", thresholds=[0.01, 50.01],
                          dataname="ICP Geometric Cases", obsname="geom000", modelname="geom001")
    look = hoods2d(hold, levels=[1, 3, 9, 17, 33, 65, 129, 257], verbose=True)
    print("h")
