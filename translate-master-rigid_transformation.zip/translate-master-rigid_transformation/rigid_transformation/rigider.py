import datetime
import numpy as np
import math
from scipy import optimize as optimize
from rigid_transformation import imomenter, fint2d, rigid_transform, q_loss_rigid
import meteva.base as meb


def rigider(grd_fo, grd_ob, init=None, func_type="regular", translate=True, rotate=False,
            interp="bicubic", stages=True, verbose=False):
    if stages and not (translate and rotate):
        stages = False
    if not translate and not rotate:
        raise Exception("rigider: one of translate or rotate must be true.")
    if verbose:
        begin_tiid = datetime.datetime.now()
    x_dim = grd_ob.shape[0]
    y_dim = grd_ob.shape[1]
    range0 = np.tile(np.arange(1, x_dim + 1), y_dim)
    range1 = (np.arange(1, y_dim + 1)).repeat(x_dim)
    p0 = np.stack((range0, range1), axis=-1)
    out = {}
    if isinstance(func_type, str):
        func_type = func_type.lower()
    elif isinstance(func_type, list):
        func_type = func_type[0].lower()
    p0 = np.array(p0)
    big_n = p0.shape[0]
    grd_fo = np.array(grd_fo)
    # 计算质心
    array_index = np.array(grd_fo.transpose() > 0).reshape((grd_fo.size, 1)).repeat(2, axis=1)
    temp_matrix = p0[array_index]
    temp_array = np.mean(temp_matrix.reshape((int(temp_matrix.size / 2), 2)), axis=0)
    field_center = np.tile(np.array(temp_array), big_n).reshape(big_n, 2, order='C')
    if func_type == "regular":
        xdim = grd_fo.shape
        if xdim != grd_ob.shape:
            raise Exception("rigider: x1 and x0 must have the same dimension.")
        outpar = np.zeros(1) + np.nan
        if init is None:
            init = [0, 0, 0]
            if verbose:
                print("Initial values not passed.  Determining good starting values now.\n")
            # 计算图片运动参数（images movements）, 获取刚体变换的初始平移量和旋转量
            # reference: Hu, M. K. (1962) Visual Pattern Recognition by Moment Invariants. IRE Trans. Info. Theory, IT-8, 179–187.
            hold1 = imomenter.imomenter(grd_fo, loc=p0)
            hold0 = imomenter.imomenter(grd_ob, loc=p0)
            tr = [hold1["centroid"]["x"] - hold0["centroid"]["x"], hold1["centroid"]["y"] - hold0["centroid"]["y"]]
            if rotate:
                init = tr
                init.append(hold1["orientation_angle"] - hold0["orientation_angle"])
            else:
                init = tr
                init.append(0)
            if verbose:
                print("initial values:\n")
                print(init)
        if (not stages) and (not translate or not rotate):
            stages = True
        if stages:
            if translate:
                if verbose:
                    print("Optimizing translation.\n")
                # 使用优化函数获取最佳变量
                res = optimize.minimize(ofun1, init[0:2],
                                        (p0, grd_fo, grd_ob, interp, big_n, field_center, xdim),
                                        "L-BFGS-B")
                if verbose:
                    print("Optimal translation found to be: ", res["x"], "\nwhere loss value is: ", res["value"],
                          "\n")
                temp_theta = np.append(res["x"], init[2])
                p1 = rigid_transform.rigid_transform(theta=temp_theta, p0=p0, n=big_n, cen=field_center)
                y1 = fint2d.fint2d(x=grd_fo, ws=p1, s=p0, method=interp)
                res["p1"] = p1
                out["grd_fo_translated"] = y1
                outpar = res["x"]
                outval = res["fun"]
            if rotate:
                if translate:
                    init2 = np.append(res["x"], init[2])
                else:
                    init2 = init
                if verbose:
                    print("Optimizing rotation.\n")
                res2 = optimize.minimize(ofun2, init2[2],
                                         (p0, grd_fo, grd_ob, interp, big_n, field_center, xdim,
                                          init2[0:2]), "L-BFGS-B")
                if verbose:
                    print("Optimal rotation found to be: ", res2["par"], "\nwhere loss value is: ", res2["value"], "\n")
                p1 = rigid_transform.rigid_transform(theta=np.array([init2[0: 2], res2["par"]]), p0=p0, n=big_n,
                                                     cen=field_center)
                y1 = fint2d.fint2d(x=grd_fo, ws=p1, s=p0, method=interp)
                outpar = np.array([outpar, res2["par"]])
                outval = res2["objective"]
        else:
            if verbose:
                print("Optimizing rigid transformation.\n")
            res = optimize.minimize(ofun3, init, (p0, grd_fo, grd_ob, interp, big_n, field_center, xdim),
                                    "L-BFGS-B")
            if verbose:
                print("Optimal transformation found to be: ", res["x"], "\nwhere loss value is: ", res["value"], "\n")
            p1 = rigid_transform.rigid_transform(theta=res["x"], p0=p0, n=big_n, cen=field_center)
            outpar = res["x"]
            outval = res["val"]
        if translate and (not rotate):
            outpar = {"x": outpar[0], "y": outpar[1]}
        elif (not translate) and rotate:
            outpar = {"angle": outpar[0]}
        else:
            outpar = {"x": outpar[0], "y": outpar[1], "angle": outpar[2]}
        if stages:
            if translate:
                out["translation_only"] = res
            if rotate:
                out["rotate"] = res2
        else:
            out["optim_object"] = res
    elif func_type == "fast":
        hold1 = imomenter.imomenter(grd_fo, loc=p0)
        hold0 = imomenter.imomenter(grd_ob, loc=p0)
        if translate:
            tr = hold1["centroid"] - hold0["centroid"]
        if rotate:
            rot = hold1["orientation_angle"] - hold0["orientation_angle"]
        if translate and rotate:
            outpar = np.array([tr, rot])
            inpar = np.array([tr, rot])
            outpar = {"x": outpar[0], "y": outpar[1], "theta": outpar[2]}
        elif (not translate) and rotate:
            outpar = rot
            inpar = np.array([0, 0, rot])
            outpar = {"theta": outpar[0]}
        elif translate and (not rotate):
            outpar = tr
            outpar = {"x": outpar[0], "y": outpar[1]}
            inpar = np.array([tr, 0])
        if stages:
            p1_tr = rigid_transform.rigid_transform(theta=tr, p0=p0, n=big_n, cen=field_center)
            y1_tr = fint2d.fint2d(x=grd_fo, ws=p1_tr, s=p0, method=interp)
            out["grd_fo_translated"] = y1_tr
        # 计算刚体变换后的坐标
        p1 = rigid_transform.rigid_transform(theta=inpar, p0=p0, n=big_n, cen=field_center)
    # 计算刚体变换后的x1
    y1 = fint2d.fint2d(x=grd_fo, ws=p1, s=p0, method=interp)
    out["func_type"] = func_type
    if func_type == "regular":
        out["initial"] = init
        out["value"] = outval
    out["interp"] = interp
    out["par"] = outpar
    out["grd_ob"] = grd_ob
    out["grd_fo"] = grd_fo
    out["p0"] = p0
    out["p1"] = p1
    out["grd_fo_transformed"] = y1
    if verbose:
        print(datetime.datetime.now() - begin_tiid)
    return out


def ofun1(theta, p0, x1, x0, interp, n, cen, xdim, tr=None):
    if theta[0] > xdim[0] / 2 + 1 or theta[1] > xdim[1] / 2 + 1:
        return 1e+16
    theta = np.array(theta)
    theta = np.append(theta, 0)
    p1 = rigid_transform.rigid_transform(theta=theta, p0=p0, n=n, cen=cen)
    y1 = fint2d.fint2d(x=x1, ws=p1, s=p0, method=interp)
    res = q_loss_rigid.q_loss_rigid(y1, x0, p1, p0)
    return res


def ofun2(theta, p0, x1, x0, interp, n, cen, xdim, tr):
    if theta > math.pi / 2 or theta < -math.pi / 2:
        return 1e+16
    theta = np.array(tr)
    theta = np.append(tr, theta)
    p1 = rigid_transform.rigid_transform(theta=theta, p0=p0, n=n, cen=cen)
    y1 = fint2d.fint2d(x=x1, ws=p1, s=p0, method=interp)
    res = q_loss_rigid.q_loss_rigid(y1, x0, p1, p0)
    return res


def ofun3(theta, p0, x1, x0, interp, n, cen, xdim, tr=None):
    if theta[0] > xdim[0] / 2 + 1 or theta[1] > xdim[1] / 2 + 1:
        return 1e+16
    if theta > math.pi / 2 or theta < -math.pi / 2:
        return 1e+16
    p1 = rigid_transform.rigid_transform(theta=theta, p0=p0, n=n, cen=cen)
    y1 = fint2d.fint2d(x=x1, ws=p1, s=p0, method=interp)
    res = q_loss_rigid.q_loss_rigid(y1, x0, p1, p0)
    return res


if __name__ == '__main__':
    file_name_ob = r'./data/ob/20070111.000.nc'
    file_name_fo = r'./data/fo/20070108.003.nc'
    grd_ob = meb.read_griddata_from_nc(file_name_ob)
    grd_fo = meb.read_griddata_from_nc(file_name_fo)
    tmp = rigider(grd_fo=grd_fo[0][0][0][0], grd_ob=grd_ob[0][0][0][0])
    # x = np.zeros((20, 40))
    # y = np.zeros((20, 40))
    # x[11:18, 1:3] = 1
    # y[12:19, 4:6] = 1
    # range0 = np.tile(np.arange(1, 21), 40)
    # range1 = (np.arange(1, 41)).repeat(20)
    # loc = np.stack((range0, range1), axis=-1)
    # tmp = rigider(grd_fo=x, grd_ob=y)
    #
    print("hello")
