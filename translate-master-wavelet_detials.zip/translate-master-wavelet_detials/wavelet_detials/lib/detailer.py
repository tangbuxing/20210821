from . import make_wave_names
from . import make_empty_wave
from . import dwt_2d
import numpy as np


def detailer(x, level, which_space="field", trans_type="DWT", use_ll=False, lnames=None, j=None):
    if lnames is None:
        if j is None:
            raise Exception("detailer: must supply j if lnames is None.")
        lnames = make_wave_names.make_wave_names(j=j)
    HH = lnames["HH"]
    HL = lnames["HL"]
    LH = lnames["LH"]
    LL = lnames["LL"]
    if which_space == "field":
        hold = make_empty_wave.make_empty_wave(x)
        if use_ll:
            hold[LL] = x[LL]
        hold[HH[level]] = x[HH[level]]
        hold[HL[level]] = x[HL[level]]
        hold[LH[level]] = x[LH[level]]
        ni = (x[HH[level]]).size * 3
        lam = np.sqrt(
            np.sum(np.power(hold[HH[level]], 2) + np.power(hold[HL[level]], 2) + np.power(hold[LH[level]], 2)) / ni)
        hold[HH[level]] = np.sign(hold[HH[level]]) * np.maximum((np.abs(hold[HH[level]]) - lam), 0)
        hold[HL[level]] = np.sign(hold[HL[level]]) * np.maximum((np.abs(hold[HL[level]]) - lam), 0)
        hold[LH[level]] = np.sign(hold[LH[level]]) * np.maximum((np.abs(hold[LH[level]]) - lam), 0)
        # if trans_type == "DWT":
        out = dwt_2d.idwt_2d(hold)
        # else:
        #     out = imodwt.2d(hold)
    else:
        out = np.power(x[HH[level]] / np.power(2, (level + 1)), 2) + np.power(x[HL[level]] / np.power(2, (level + 1)), 2) + np.power(x[LH[level]] / np.power(2, (level + 1)), 2)
    return out
