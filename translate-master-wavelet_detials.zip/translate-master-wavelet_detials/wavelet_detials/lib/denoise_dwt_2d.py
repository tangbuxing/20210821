# -*- coding: utf-8 -*-
import math
import numpy as np
from .dwt_2d import dwt_2d_for_denoise


def denoise_dwt_2d(x, j=4, method="universal", noise_dir=3, rule="hard"):
    res = {}
    # len_lat纬度方向的长度
    len_lat = math.log2(x.shape[0])
    # len_lon经度方向的长度
    len_lon = math.log2(x.shape[1])

    if len_lat.is_integer() and len_lon.is_integer():
        res = dwt_2d_for_denoise(x=x, j=j, method=method, noise_dir=noise_dir, rule=rule)
    else:
        # 如果纬度方向不满足
        if len_lat.is_integer():
            print("宽的长度满足2的n次方")
        else:
            x_extend_01 = np.full(shape=(abs(x.shape[0] - x.shape[1]), x.shape[1]), fill_value=0)
            x_extend = np.vstack((x, x_extend_01))
            res = dwt_2d_for_denoise(x=x_extend, j=j, method=method, noise_dir=noise_dir, rule=rule)
        # 如果经度方向不满足
        if len_lon.is_integer():
            print("长的长度满足2的n次方")
        else:
            x_extend_01 = np.full(shape=(x.shape[0], abs(x.shape[0] - x.shape[1])), fill_value=0)
            x_extend = np.hstack((x, x_extend_01))
            res = dwt_2d_for_denoise(x=x_extend, j=j, method=method, noise_dir=noise_dir, rule=rule)
        # 如果纬度、经度方向都不满足
        if not (len_lat.is_integer() and len_lon.is_integer()):
            xy_max = max(math.ceil(len_lat), math.ceil(len_lon))
            x_extend_01 = np.full(shape=(x.shape[0], abs(x.shape[1] - 2 ** xy_max)), fill_value=0)
            x_extend_x = np.hstack((x, x_extend_01))
            x_extend_02 = np.full(shape=(abs(x.shape[0] - 2 ** xy_max), x_extend_x.shape[1]), fill_value=0)
            x_extend_xy = np.vstack((x_extend_x, x_extend_02))
            res = dwt_2d_for_denoise(x=x_extend_xy, j=j, method=method, noise_dir=noise_dir, rule=rule)

    res = res[:x.shape[0], :x.shape[1]]
    return res
