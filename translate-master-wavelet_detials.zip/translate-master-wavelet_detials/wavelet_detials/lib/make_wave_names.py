
def make_wave_names(j):
    hh = {}
    hl = {}
    lh = {}
    ll = {}
    for i in range(1, j + 1):
        hh[i - 1] = "HH" + str(i)
        hl[i - 1] = "HL" + str(i)
        lh[i - 1] = "LH" + str(i)
        ll[i - 1] = "LL" + str(j)
    out = {"HH": hh, "HL": hl, "LH": lh, "LL": ll}
    return out

