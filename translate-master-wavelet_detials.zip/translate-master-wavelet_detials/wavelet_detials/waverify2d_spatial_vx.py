from wavelet_detials.lib.datagrabber_spatialVx import datagrabber_spatialVx
from wavelet_detials.waverify2d_default import waverify2d_default
import pyreadr
from wavelet_detials.lib.make_spatialVx import make_spatialVx


def waverify2d_spatial_vx(input_object, clim=None, wavelet_type="haar", j=None, use_ll=False, compute_shannon=False,
                          which_space="field",
                          time_point=1, obs=1, model=1, verbose=False):
    out = {}
    dat = datagrabber_spatialVx(input_object, time_point=time_point, obs=obs, model=model)
    grd_ob = dat["X"]
    grd_fo = dat["Xhat"]
    out2 = waverify2d_default(grd_ob=grd_ob, grd_fo=grd_fo, clim=clim, wavelet_type=wavelet_type, j=j, use_ll=use_ll,
                              compute_shannon=compute_shannon, which_space=which_space, verbose=verbose)
    out["grd_ob_wave"] = out2["grd_ob_wave"]
    out["grd_fo_wave"] = out2["grd_fo_wave"]
    if out2.keys().__contains__("clim_wave"):
        out["clim_wave"] = out2["clim_wave"]
    if out2.keys().__contains__("shannon_entropy"):
        out["shannon_entropy"] = out2["shannon_entropy"]
    if out2.keys().__contains__("energy"):
        out["energy"] = out2["energy"]
    out["mse"] = out2["mse"]
    out["rmse"] = out2["rmse"]
    if out2.keys().__contains__("acc"):
        out["acc"] = out2["acc"]
    return out


if __name__ == '__main__':
    obs = pyreadr.read_r('./data/UKobs6.Rdata')['UKobs6']
    fcst = pyreadr.read_r('./data/UKfcst6.Rdata')['UKfcst6']
    loc = pyreadr.read_r('./data/UKloc.Rdata')['UKloc']
    hold = make_spatialVx(obs, fcst, loc, fieldtype="Rainfall", units="mm/h", dataname="Nimrod",
                          obsname="UKobs6", modelname="UKfcst6", thresholds=[0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50])
    res1 = waverify2d_spatial_vx(hold, compute_shannon=True)
    print("h")
