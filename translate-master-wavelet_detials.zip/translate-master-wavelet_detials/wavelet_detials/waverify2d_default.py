import datetime
import numpy as np
import math
from wavelet_detials.lib.make_wave_names import make_wave_names
from wavelet_detials.lib.dwt_2d import dwt_2d
from wavelet_detials.lib.detailer import detailer


def waverify2d_default(grd_ob, grd_fo, clim=None, wavelet_type="haar", j=None, use_ll=False, compute_shannon=False,
                       which_space="field", verbose=False):
    if verbose:
        begin_time = datetime.datetime.now()
    out = {}
    atmp = {"loc_byrow": False}
    climate = not (clim is None)
    grd_fo = np.array(grd_fo)
    n = grd_fo.shape[0]
    if j is None:
        j = math.log(n, 2)
    try:
        j = int(j)
    except ArithmeticError:
        raise Exception("y shape should be the power of 2")
    wv_x = dwt_2d(grd_ob, j=j, wavelet_type=wavelet_type)
    wv_y = dwt_2d(grd_fo, j=j, wavelet_type=wavelet_type)
    if climate:
        wv_clim = dwt_2d(clim, j=j, wavelet_type=wavelet_type)
    out["grd_fo_wave"] = wv_y
    out["grd_ob_wave"] = wv_x
    if climate:
        out["clim_wave"] = wv_clim
    if compute_shannon:
        shannon_entropy = np.zeros((1, 2)) + np.nan
        array_x = []
        for key in wv_x:
            array_x = array_x + [i for j in wv_x[key] for i in j]
        tmp = np.abs(array_x)
        tmp = tmp / np.nansum(tmp)
        id0 = (tmp == 0)
        tmp[~id0] = tmp[~id0] * np.log(tmp[~id0])
        shannon_entropy[:, 0] = -np.nansum(tmp)
        array_y = []
        for key in wv_y:
            array_y = array_y + [i for j in wv_y[key] for i in j]
        tmp = np.abs(array_y)
        tmp = tmp / np.nansum(tmp)
        id0 = (tmp == 0)
        tmp[~id0] = tmp[~id0] * np.log(tmp[~id0])
        shannon_entropy[:, 1] = -np.nansum(tmp)
        out["shannon_entropy"] = shannon_entropy
    tmp = make_wave_names(j)
    hh = tmp["HH"]
    hl = tmp["HL"]
    lh = tmp["LH"]
    ll = tmp["LL"]
    mse_i = np.zeros(j) + np.nan
    rmse_i = np.zeros(j) + np.nan
    if climate:
        acc_i = rmse_i
    if not climate:
        energy_i = np.zeros((j, 2)) + np.nan
    else:
        energy_i = np.zeros((j, 3)) + np.nan
    if verbose:
        print("\n", "calculating statistics at each level.\n")
    for i in range(0, j):
        if verbose:
            print(i, " ")
        energy_i[i, 0] = np.nansum(np.power(wv_x[hh[i]], 2)) + np.nansum(np.power(wv_x[hl[i]], 2)) + np.nansum(
            np.power(wv_x[lh[i]], 2))
        energy_i[i, 1] = np.nansum(np.power(wv_y[hh[i]], 2)) + np.nansum(np.power(wv_y[hl[i]], 2)) + np.nansum(
            np.power(wv_y[lh[i]], 2))
        if climate:
            energy_i[i, 2] = np.nansum(wv_clim[hh[i]] ^ 2) + np.nansum(wv_clim[hl[i]] ^ 2) + np.nansum(
                wv_clim[lh[i]] ^ 2)
        if verbose:
            if which_space == "field":
                print("Finding inverse transforms for this scale (i.e., detail reconstruction).\n")
            else:
                print("Finding coefficient detail for this scale.\n")

        inv_hold0_i = detailer(wv_x, level=i, which_space=which_space, use_ll=use_ll, lnames=tmp)
        inv_hold1_i = detailer(wv_y, level=i, which_space=which_space, use_ll=use_ll, lnames=tmp)
        if climate:
            inv_hold2_i = detailer(wv_clim, level=i, which_space=which_space, use_ll=use_ll, lnames=tmp)
        if verbose:
            print("Inverse transforms for present scale found.  Calculating vx stats.\n")
        mse_i[i] = np.mean(np.power(inv_hold0_i - inv_hold1_i, 2))
        rmse_i[i] = np.sqrt(mse_i[i])
        if climate:
            if verbose:
                print("Calculating ACC.\n")
            denom = np.sqrt(np.sum(np.power(inv_hold0_i - inv_hold2_i, 2))) * np.sqrt(
                np.sum(np.power(inv_hold1_i - inv_hold2_i, 2)))
            numer = np.nansum(np.diag(np.dot((inv_hold0_i - inv_hold2_i).transpose(), (inv_hold1_i - inv_hold2_i))))
            acc_i[i] = numer / denom
            if verbose:
                print("ACC calculated.\n")
    out["energy"] = energy_i
    out["mse"] = mse_i
    out["rmse"] = rmse_i
    if climate:
        out["acc"] = acc_i
    out["type"] = wavelet_type
    if verbose:
        print(datetime.datetime.now() - begin_time)
    atmp["class"] = "waverify2d"
    out["attributes"] = atmp
    return out
