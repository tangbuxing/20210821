import datetime
import numpy as np
import math
from wavelet_detials.lib.denoise_dwt_2d import denoise_dwt_2d
from wavelet_detials.lib.thresholder import thresholder
from wavelet_detials.lib.vxstats import vxstats


def wavepurifyVx_default(x, climate=None, which_stats=None, thresholds=None, rule=">=", return_fields=False,
                         verbose=False):
    if which_stats is None:
        which_stats = ["bias", "ts", "ets", "pod", "far", "f", "hk", "mse"]
    if verbose:
        begin_time = datetime.datetime.now()
    if verbose:
        print(thresholds)
    # if (is.list(x) && all(is.element(c("X", "Xhat"), names(x)))):
    x_data = np.array(x["X"])
    xhat_data = np.array(x["Xhat"])
    # elif (is.list(x) && length(x) == 2) {
    #   X = x[[1]]
    #   Xhat = x[[2]]
    # }
    # elif (is.array(x) && dim(x)[3] == 2) {
    #   X = x[, , 1]
    #   Xhat = x[, , 2]
    # }
    # else:
    #   raise Exception("wavePurifyVx: invalid x argument.")
    xdim = x_data.shape
    out = {}
    if xdim != xhat_data.shape:
        raise Exception("wavePurifyVx: dimensions of verification and modelfield must be the same.")
    if thresholds is None and [val for val in which_stats if
                               val in ["bias", "ts", "ets", "pod", "far", "f", "hk"]] is not None:
        thresholds = np.quantile(xhat_data, [0, 0.1, 0.25, 0.33, 0.5, 0.66, 0.75, 0.9, 0.95]) + np.quantile(x_data,
                                                                                                            [0, 0.1,
                                                                                                             0.25, 0.33,
                                                                                                             0.5, 0.66,
                                                                                                             0.75, 0.9,
                                                                                                             0.95])
        out["qs"] = [0, 0.1, 0.25, 0.33, 0.5, 0.66, 0.75, 0.9, 0.95]
    else:
        if not thresholds.__contains__("X") and not thresholds.__contains__("Xhat"):
            raise Exception("wavePurifyVx: invalid thresholds argument.  Must have X and Xhat components.")
        thresholds = np.hstack((thresholds["Xhat"], thresholds["X"]))
        out["thresholds"] = thresholds
    # isnt_j = True
    args = {}
    j = math.floor(math.log2(min(xdim)))
    args["J"] = j
    out["args"] = args
    if (np.floor(np.log2(xdim)) == np.ceil(np.log2(xdim))).all():
        dyadic = True
    else:
        dyadic = False
    if verbose:
        print("\n", "Denoising the fields.\n")
    # if dyadic:
        #   if isnt_j:
    z = denoise_dwt_2d(x=x_data, J=j)
    y = denoise_dwt_2d(x=xhat_data, J=j)
    if climate is not None:
        climate2 = denoise_dwt_2d(x=climate, J=j)
        # else:
        #   z = denoise_dwt_2d(x = x_data)
        #   y = denoise_dwt_2d(x = xhat_data)
        #   if climate is not None:
        #     climate2 = denoise_dwt_2d(x = climate)
    # else:
    #   if isnt_j:
    #     z = denoise_dwt_2d(x = x_data, J = j)
    #     y = denoise_dwt_2d(x = xhat_data, J = j)
    #     if climate is not None:
    #       climate2 = denoise_dwt_2d(x = climate, J = j)
    #   else:
    #     z = denoise_dwt_2d(x = x_data)
    #     y = denoise_dwt_2d(x = xhat_data)
    #     if climate is not None:
    #       climate2 = denoise_dwt_2d(x = climate)
    if return_fields:
        out["X"] = x_data
        out["Xhat"] = xhat_data
        out["X2"] = z
        out["Y2"] = y
        if climate is not None:
            out["Climate"] = climate
            out["Climate2"] = climate2
    if thresholds is not None:
        q = thresholds.shape[0]
    else:
        q = 1
    if "bias" in which_stats:
        out["bias"] = np.zeros(q) + np.nan
    if "ts" in which_stats:
        out["ts"] = np.zeros(q) + np.nan
    if "ets" in which_stats:
        out["ets"] = np.zeros(q) + np.nan
    if "pod" in which_stats:
        out["pod"] = np.zeros(q) + np.nan
    if "far" in which_stats:
        out["far"] = np.zeros(q) + np.nan
    if "f" in which_stats:
        out["f"] = np.zeros(q) + np.nan
    if "hk" in which_stats:
        out["hk"] = np.zeros(q) + np.nan
    if "mse" in which_stats:
        out["mse"] = np.zeros(q) + np.nan
    if climate is not None:
        out["acc"] = np.zeros(q) + np.nan
    if verbose:
        print("\n", "Looping through thresholds = \n")
        print(thresholds)
        print("\n")
    for threshold in np.arange(0, q):
        if verbose:
            print(threshold + " ")
        if "mse" in which_stats:
            if thresholds is not None:
                x2 = thresholder(x=z, func_type="replace_below", th=thresholds[threshold, 1], rule=rule)
                y2 = thresholder(x=y, func_type="replace_below", th=thresholds[threshold, 0], rule=rule)
                out["mse"][threshold] = vxstats(y2, x2, which_stats="mse")["mse"]
            else:
                out["mse"][threshold] = vxstats(y, z, which_stats="mse")["mse"]
        if [val for val in which_stats if val in ["bias", "ts", "ets", "pod", "far", "f", "hk"]] is not None:
            xbin = thresholder(x=z, func_type="binary", th=thresholds[threshold, 1], rule=rule)
            ybin = thresholder(x=y, func_type="binary", th=thresholds[threshold, 0], rule=rule)
            dostats = which_stats
            if threshold == 0:
                if "mse" in dostats:
                    dostats.remove("mse")
            tmp = vxstats(ybin, xbin, which_stats=dostats)
            if "bias" in which_stats:
                out["bias"][threshold] = tmp["bias"]
            if "ts" in which_stats:
                out["ts"][threshold] = tmp["ts"]
            if "ets" in which_stats:
                out["ets"][threshold] = tmp["ets"]
            if "pod" in which_stats:
                out["pod"][threshold] = tmp["pod"]
            if "far" in which_stats:
                out["far"][threshold] = tmp["far"]
            if "f" in which_stats:
                out["f"][threshold] = tmp["f"]
            if "hk" in which_stats:
                out["hk"][threshold] = tmp["hk"]
        if climate is not None:
            if thresholds is not None:
                x2 = thresholder(x=z, type="replace.below", th=thresholds[threshold, 2], rule=rule)
                y2 = thresholder(x=y, type="replace.below", th=thresholds[threshold, 1], rule=rule)
                Clim = thresholder(x=climate2, type="replace.below", th=thresholds[threshold, 1], rule=rule)
                denom = np.sqrt(np.nansum(np.power(y2 - Clim, 2))) * np.sqrt(np.nansum(np.power(x2 - Clim, 2)))
                numer = np.nansum(np.diag(np.dot((y2 - Clim).transpose(), x2 - Clim)))
            else:
                denom = np.sqrt(np.nansum(np.power(y - climate2, 2))) * np.sqrt(np.nansum(np.power(z - climate2, 2)))
                numer = np.nansum(np.diag(np.dot((y - climate2).transpose(), z - climate2)))
            out["acc"][threshold] = numer / denom
    if verbose:
        print(datetime.datetime.now() - begin_time)
    return out
