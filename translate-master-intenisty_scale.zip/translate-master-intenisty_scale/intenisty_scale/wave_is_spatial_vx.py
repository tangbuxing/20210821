from intenisty_scale.lib.datagrabber_spatialVx import datagrabber_spatialVx
from intenisty_scale.wave_is_default import wave_is_default
from intenisty_scale.lib.util import get_attributes
import pyreadr
from intenisty_scale.lib.make_spatialVx import make_spatialVx
import numpy as np


def wave_is_spatial_vx(input_object, th=None, j=None, levels=None, rule=">=", verbose=False, time_point=1, obs=1, model=1):
    attributes = get_attributes(input_object)
    if th is None:
        th = {"X": attributes["thresholds"][0][:, obs - 1], "Xhat": attributes["thresholds"][1][:, model - 1]}
    # 根据time_point， obs， model 提取数据
    dat = datagrabber_spatialVx(input_object, time_point=time_point - 1, obs=obs - 1, model=model - 1)
    out = wave_is_default(grd_ob=dat["X"], grd_fo=dat["Xhat"], th=th, j=j, levels=levels, rule=rule, verbose=verbose)
    if isinstance(input_object["time"], list):
        attributes["time"] = input_object["time"][time_point]
    else:
        attributes["time"] = input_object["time"]
    if isinstance(input_object["obsname"], list):
        attributes["obs_name"] = input_object["obsname"][obs]
    else:
        attributes["obs_name"] = input_object["obsname"]
    if isinstance(input_object["modelname"], list):
        attributes["model.name"] = input_object["modelname"][model]
    else:
        attributes["model.name"] = input_object["modelname"]
    attributes["rule"] = rule
    attributes["levels"] = levels
    attributes["class"] = "waveIS"
    out_attributes = out["attributes"]
    new_attributes = {**attributes, **out_attributes}
    out["attributes"] = new_attributes
    return out


if __name__ == '__main__':
    obs = pyreadr.read_r('./data/UKobs6.Rdata')['UKobs6']
    fcst = pyreadr.read_r('./data/UKfcst6.Rdata')['UKfcst6']
    loc = pyreadr.read_r('./data/UKloc.Rdata')['UKloc']
    hold = make_spatialVx(obs, fcst, loc, fieldtype="Rainfall", units="mm/h", dataname="Nimrod",
                          obsname="UKobs6", modelname="UKfcst6", thresholds=[0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50])
    look = wave_is_spatial_vx(hold, j=8, levels=np.power(2, np.arange(7, -1, -1)))
    print("hj")
