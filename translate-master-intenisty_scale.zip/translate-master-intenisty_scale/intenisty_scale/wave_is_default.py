import datetime
import numpy as np
from intenisty_scale.lib.dwt_2d import dwt_2d
from intenisty_scale.lib.make_wave_names import make_wave_names
from intenisty_scale.lib.energizer import energizer
from intenisty_scale.lib.detailer import detailer
from intenisty_scale.lib.thresholder import thresholder


def wave_is_default(grd_ob, grd_fo, th, j=None, levels=None, rule=">=", verbose=False):
    if verbose:
        begin_time = datetime.datetime.now()
    if [False for c in ["X", "Xhat"] if c not in th]:
        raise Exception("waveIS: invalid th argument.  Must have components X and Xhat.")
    xdim = np.array(grd_ob).shape
    if not xdim == np.array(grd_fo).shape:
        raise Exception("waveIS: invalid x argument.  Dimensions of two fields must be the same.")
    attributes = {"xdim": xdim}
    out = {}
    thresholds = th
    q = np.array(thresholds["X"]).shape[0]
    big_n = np.array(grd_ob).size
    j_try = np.log2(xdim)
    # 判断是否为 dyadic
    if (np.floor(j_try) == np.ceil(j_try)).all():
        dyadic = True
    else:
        dyadic = False
    if j is None:
        if dyadic:
            j = np.min(np.ma.masked_array(j_try, np.isnan(j_try)))
        else:
            j = 4
    e_x = np.zeros((j, q)) + np.nan
    e_y = np.zeros((j, q)) + np.nan
    mse = np.zeros((j, q)) + np.nan
    ss = np.zeros((j, q)) + np.nan
    bias = np.zeros(q) + np.nan
    mserand = np.zeros(q) + np.nan
    if verbose:
        print("\n", "Looping through thresholds = \n")
    # 根据各threshold计算相关参数
    for threshold in range(0, q):
        if verbose:
            print("\nThreshold ", threshold, "\n")
        x_bin = thresholder(grd_ob, func_type="binary", th=th["X"][threshold], rule=rule)
        y_bin = thresholder(grd_fo, func_type="binary", th=th["Xhat"][threshold], rule=rule)
        s = np.nansum(x_bin)
        if s == 0:
            b = np.nan
        else:
            b = np.nansum(y_bin) / s
        s = s / big_n
        bias[threshold] = b
        mse_random = b * s * (1 - s) + s * (1 - b * s)
        mserand[threshold] = mse_random
        # if dyadic:
        wv_x = dwt_2d(x_bin, j=j)
        wv_y = dwt_2d(y_bin, j=j)
        wv_diff = dwt_2d(y_bin - x_bin, j=j)
        # else:
        #     wv_x = modwt_2d.modwt_2d(x_bin, wf=wavelet_type, j=j)
        #     wv_y = modwt_2d.modwt_2d(y_bin, wf=wavelet_type, j=j)
        #     wv_diff = modwt_2d.modwt_2d(y_bin - x_bin, wf=wavelet_type, j=j)
        lnames = None
        if threshold == 0:
            lnames = make_wave_names(j=j)
        e_x[:, threshold] = energizer(wv_x, lnames=lnames, j=j)
        e_y[:, threshold] = energizer(wv_y, lnames=lnames, j=j)
        for index in range(0, j):
            hold = detailer(wv_diff, level=index, which_space="wavelet", lnames=lnames, j=j)
            n = (np.ma.masked_array(hold, np.isnan(hold))).size
            mse_ui = np.nansum(hold) / n
            mse[index, threshold] = mse_ui
            ss[index, threshold] = 1 - (mse_ui * (j + 1)) / mse_random
    if verbose:
        print("\n", "Finished computing DWTs for each threshold.\n")
    out["j"] = j
    out["en_vx"] = e_x
    out["en_fcst"] = e_y
    out["mse"] = mse
    out["bias"] = bias
    out["ss"] = ss
    out["mse_random"] = mserand
    attributes["rule"] = rule
    attributes["levels"] = levels
    attributes["thresholds"] = th
    attributes["qs"] = range(1, np.array(th["X"]).shape[0] + 1)
    attributes["xdim"] = xdim
    attributes["map"] = False
    attributes["class"] = "waveIS"
    out["attributes"] = attributes
    if verbose:
        print(datetime.datetime.now() - begin_time)
    return out
