from .make_wave_names import make_wave_names
import numpy as np


def energizer(x, lnames=None, j=None):
    if j is None:
        j = (len(x) - 1) / 3
    if lnames is None:
        lnames = make_wave_names(j=j)
    hh = lnames["HH"]
    hl = lnames["HL"]
    lh = lnames["LH"]
    out = np.zeros(j) + np.nan
    for i in range(0, j):
        good = ~((x[hh[i]] == np.nan) * (x[hl[i]] == np.nan) * (x[lh[i]] == np.nan))
        n = len(x[hh[i]][good])
        out[i] = np.nansum(np.power(x[hh[i]], 2) + np.power(x[hl[i]], 2) + np.power(x[lh[i]], 2)) / n
    return out
