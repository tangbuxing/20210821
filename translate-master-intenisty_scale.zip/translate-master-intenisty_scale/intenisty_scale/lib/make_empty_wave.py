import copy


def make_empty_wave(x):
    hold = copy.deepcopy(x)
    for key in hold:
        hold[key] = hold[key] * 0
    return hold
